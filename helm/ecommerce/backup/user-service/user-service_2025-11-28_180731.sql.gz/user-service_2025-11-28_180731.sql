-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: user-service_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `full_address` varchar(255) DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`address_id`),
  KEY `fk1_assign` (`user_id`),
  CONSTRAINT `fk1_assign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,1,'carthage byrsa','2016','carthage','2025-11-28 15:55:24',NULL),(2,2,'carthage byrsa','2016','carthage','2025-11-28 15:55:24',NULL),(3,3,'carthage byrsa','2016','carthage','2025-11-28 15:55:24',NULL),(4,4,'carthage byrsa','2016','carthage','2025-11-28 15:55:24',NULL),(5,2,'kram','2015','kram','2025-11-28 15:55:24',NULL),(6,1,'kram','2015','kram','2025-11-28 15:55:24',NULL);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credentials`
--

DROP TABLE IF EXISTS `credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credentials` (
  `credential_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `is_account_non_expired` tinyint(1) DEFAULT '1',
  `is_account_non_locked` tinyint(1) DEFAULT '1',
  `is_credentials_non_expired` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`credential_id`),
  KEY `fk2_assign` (`user_id`),
  CONSTRAINT `fk2_assign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credentials`
--

LOCK TABLES `credentials` WRITE;
/*!40000 ALTER TABLE `credentials` DISABLE KEYS */;
INSERT INTO `credentials` VALUES (1,1,'selimhorri','$2a$04$/S7cWjHPZul03sPEivycWeKTBvLyjYdaRWmeaFbiqKy9es/3W4QB6','ROLE_USER',1,1,1,1,'2025-11-28 15:55:24',NULL),(2,2,'amineladjimi','$2a$04$8D8OuqPbE4LhRckvtBAHrOmpeWmE92xNNVtyK8Z/lrJFjsImpjBkm','ROLE_USER',1,1,1,1,'2025-11-28 15:55:24',NULL),(3,3,'omarderouiche','$2a$04$jelNGcF4wFHJirT5Pm7jPO8812QE/3tIWIs1DNnajS68iG4aKUqvS','ROLE_USER',1,1,1,1,'2025-11-28 15:55:24',NULL),(4,4,'admin','$2a$04$1G4TwSzwf5JwZ4dKCXG1Zu1Qh3WIY9JNaM9vF6Ff05QDfyPg7nSxO','ROLE_USER',1,1,1,1,'2025-11-28 15:55:24',NULL);
/*!40000 ALTER TABLE `credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','create users table','SQL','V1__create_users_table.sql',-1475574202,'user','2025-11-28 15:55:23',70,1),(2,'2','insert users table','SQL','V2__insert_users_table.sql',230334033,'user','2025-11-28 15:55:24',41,1),(3,'3','create address table','SQL','V3__create_address_table.sql',-1644149139,'user','2025-11-28 15:55:24',69,1),(4,'4','insert address table','SQL','V4__insert_address_table.sql',1643573553,'user','2025-11-28 15:55:24',36,1),(5,'5','create credentials table','SQL','V5__create_credentials_table.sql',22672514,'user','2025-11-28 15:55:24',106,1),(6,'6','insert credentials table','SQL','V6__insert_credentials_table.sql',-505415013,'user','2025-11-28 15:55:24',15,1),(7,'7','create verification tokens table','SQL','V7__create_verification_tokens_table.sql',-1173038933,'user','2025-11-28 15:55:25',103,1),(8,'8','insert verification tokens table','SQL','V8__insert_verification_tokens_table.sql',-1135106652,'user','2025-11-28 15:55:25',30,1),(9,'9','create address user id fk','SQL','V9__create_address_user_id_fk.sql',-374981048,'user','2025-11-28 15:55:25',182,1),(10,'10','create credentials user id fk','SQL','V10__create_credentials_user_id_fk.sql',582227868,'user','2025-11-28 15:55:25',153,1),(11,'11','create verification tokens credential id fk','SQL','V11__create_verification_tokens_credential_id_fk.sql',137268596,'user','2025-11-28 15:55:25',149,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT 'https://bootdey.com/img/Content/avatar/avatar7.png',
  `email` varchar(255) DEFAULT 'springxyzabcboot@gmail.com',
  `phone` varchar(255) DEFAULT '+21622125144',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'selim','horri','https://bootdey.com/img/Content/avatar/avatar7.png','springxyzabcboot@gmail.com','+21622125144','2025-11-28 15:55:24',NULL),(2,'amine','ladjimi','https://bootdey.com/img/Content/avatar/avatar7.png','springxyzabcboot@gmail.com','+21622125144','2025-11-28 15:55:24',NULL),(3,'omar','derouiche','https://bootdey.com/img/Content/avatar/avatar7.png','springxyzabcboot@gmail.com','+21622125144','2025-11-28 15:55:24',NULL),(4,'admin','admin','https://bootdey.com/img/Content/avatar/avatar7.png','springxyzabcboot@gmail.com','+21622125144','2025-11-28 15:55:24',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_tokens`
--

DROP TABLE IF EXISTS `verification_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_tokens` (
  `verification_token_id` int NOT NULL AUTO_INCREMENT,
  `credential_id` int DEFAULT NULL,
  `verif_token` varchar(255) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`verification_token_id`),
  KEY `fk3_assign` (`credential_id`),
  CONSTRAINT `fk3_assign` FOREIGN KEY (`credential_id`) REFERENCES `credentials` (`credential_id`),
  CONSTRAINT `verification_tokens_ibfk_1` FOREIGN KEY (`credential_id`) REFERENCES `credentials` (`credential_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_tokens`
--

LOCK TABLES `verification_tokens` WRITE;
/*!40000 ALTER TABLE `verification_tokens` DISABLE KEYS */;
INSERT INTO `verification_tokens` VALUES (1,1,'','2021-12-31','2025-11-28 15:55:25','2025-11-28 15:55:25'),(2,2,'','2021-12-31','2025-11-28 15:55:25','2025-11-28 15:55:25'),(3,3,'','2021-12-31','2025-11-28 15:55:25','2025-11-28 15:55:25'),(4,4,'','2021-12-31','2025-11-28 15:55:25','2025-11-28 15:55:25');
/*!40000 ALTER TABLE `verification_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-28 18:07:31
